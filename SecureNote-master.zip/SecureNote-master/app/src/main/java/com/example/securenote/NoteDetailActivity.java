package com.example.securenote;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class NoteDetailActivity extends AppCompatActivity {

    public static final String EXTRA_ID = "extra_id";
    public static final String EXTRA_TITLE = "extra_title";
    public static final String EXTRA_CONTENT = "extra_content";

    private EditText etTitle;
    private EditText etContent;

    private NoteManager manager;
    private String noteId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_detail);

        // init manager
        NoteManager.init(this);
        manager = NoteManager.get();

        // views
        ImageButton btnBack = findViewById(R.id.btnBack);
        etTitle = findViewById(R.id.etDetailTitle);
        etContent = findViewById(R.id.etDetailContent);

        // รับข้อมูลจาก MainActivity
        noteId = getIntent().getStringExtra(EXTRA_ID);
        String title = getIntent().getStringExtra(EXTRA_TITLE);
        String content = getIntent().getStringExtra(EXTRA_CONTENT);

        if (title != null) etTitle.setText(title);
        if (content != null) etContent.setText(content);

        // ปุ่มย้อนกลับ
        btnBack.setOnClickListener(v -> finish());
    }

    // ฟังก์ชันเซฟอัตโนมัติ
    private void saveNoteIfPossible() {
        if (noteId == null) return;

        String newTitle = etTitle.getText().toString();
        String newContent = etContent.getText().toString();

        manager.updateNote(noteId, newTitle, newContent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // ทุกครั้งที่หน้าถูก pause (เช่น กด back / สลับแอป) จะเซฟให้
        saveNoteIfPossible();
    }
}