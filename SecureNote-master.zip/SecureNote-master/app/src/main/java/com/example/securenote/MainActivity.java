package com.example.securenote;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private NotesAdapter adapter;
    private NoteManager manager;
    private TextView tvEmpty;

    private EditText etSearch;
    private ImageButton btnAdd;

    // เก็บ note ทั้งหมดไว้สำหรับใช้ตอนค้นหา
    private List<NoteManager.Note> allNotes = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_ios);

        // init manager
        NoteManager.init(this);
        manager = NoteManager.get();

        // RecyclerView + Adapter
        RecyclerView rv = findViewById(R.id.rvNotes);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NotesAdapter(new NotesAdapter.Listener() {
            @Override
            public void onClick(NoteManager.Note n) {
                Intent intent = new Intent(MainActivity.this, NoteDetailActivity.class);
                intent.putExtra(NoteDetailActivity.EXTRA_ID, n.id);       // ✅ ส่ง id ไป
                intent.putExtra(NoteDetailActivity.EXTRA_TITLE, n.title);
                intent.putExtra(NoteDetailActivity.EXTRA_CONTENT, n.content);
                startActivity(intent);
            }

            @Override
            public void onLongClick(NoteManager.Note n) {
                showEditDelete(n);
            }
        });
        rv.setAdapter(adapter);

        tvEmpty = findViewById(R.id.tvEmpty);

        // bottom bar
        etSearch = findViewById(R.id.etSearch);
        btnAdd = findViewById(R.id.btnAdd);

        // ปุ่ม + เพิ่ม note ใหม่ (เหมือน fab เดิม)
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditDialog(null);
            }
        });

        // ค้นหา note จาก title หรือ content
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                String q = s.toString().toLowerCase(Locale.getDefault());
                if (TextUtils.isEmpty(q)) {
                    // ถ้าไม่มีข้อความค้นหา แสดงทั้งหมด
                    adapter.setItems(allNotes);
                    tvEmpty.setVisibility(allNotes.isEmpty() ? View.VISIBLE : View.GONE);
                    return;
                }

                List<NoteManager.Note> filtered = new ArrayList<>();
                for (NoteManager.Note n : allNotes) {
                    String title = n.title == null ? "" : n.title;
                    String content = n.content == null ? "" : n.content;
                    if (title.toLowerCase(Locale.getDefault()).contains(q) ||
                            content.toLowerCase(Locale.getDefault()).contains(q)) {
                        filtered.add(n);
                    }
                }
                adapter.setItems(filtered);
                tvEmpty.setVisibility(filtered.isEmpty() ? View.VISIBLE : View.GONE);
            }
        });

        // โหลด note ครั้งแรก
        refreshList();
    }
    @Override
    protected void onResume() {
        super.onResume();
        // กลับมาจากหน้ารายละเอียดเมื่อไหร่ ให้โหลดรายการใหม่
        refreshList();
    }

    private void refreshList() {
        allNotes = manager.getAll();        // ดึงทั้งหมดจาก storage
        adapter.setItems(allNotes);
        tvEmpty.setVisibility(allNotes.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showEditDialog(final NoteManager.Note edit) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);

        View view = LayoutInflater.from(this)
                .inflate(R.layout.dialog_note_ios, null, false);

        EditText etTitle = view.findViewById(R.id.etTitle);
        EditText etContent = view.findViewById(R.id.etContent);

        if (edit != null) {
            etTitle.setText(edit.title);
            etContent.setText(edit.content);
        }

        b.setView(view);
        b.setPositiveButton(getString(R.string.save), (dialog, which) -> {
            String t = etTitle.getText().toString().trim();
            String c = etContent.getText().toString().trim();
            if (TextUtils.isEmpty(t) && TextUtils.isEmpty(c)) {
                Toast.makeText(MainActivity.this,
                        "กรอกข้อมูลก่อนบันทึก", Toast.LENGTH_SHORT).show();
                return;
            }
            if (edit == null) {
                manager.addNote(t, c);
            } else {
                manager.updateNote(edit.id, t, c);
            }
            refreshList();
        });
        b.setNegativeButton(getString(R.string.cancel), null);
        b.show();
    }

    private void showViewNote(final NoteManager.Note n) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(n.title);
        builder.setMessage(n.content);
        builder.setPositiveButton("ปิด", null);
        builder.setNeutralButton("แก้ไข", (dialog, which) -> showEditDialog(n));
        builder.setNegativeButton("ลบ", (dialog, which) -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("ยืนยัน")
                    .setMessage("ต้องการลบใช่หรือไม่")
                    .setPositiveButton("ลบ", (d, w) -> {
                        manager.deleteNote(n.id);
                        refreshList();
                    })
                    .setNegativeButton("ยกเลิก", null)
                    .show();
        });
        builder.show();
    }

    private void showEditDelete(final NoteManager.Note n) {
        new AlertDialog.Builder(this)
                .setItems(new CharSequence[]{"แก้ไข", "ลบ"}, (dialog, which) -> {
                    if (which == 0) {
                        showEditDialog(n);
                    } else {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("ยืนยัน")
                                .setMessage("ต้องการลบใช่หรือไม่")
                                .setPositiveButton("ลบ", (d, w) -> {
                                    manager.deleteNote(n.id);
                                    refreshList();
                                })
                                .setNegativeButton("ยกเลิก", null)
                                .show();
                    }
                })
                .show();
    }
}